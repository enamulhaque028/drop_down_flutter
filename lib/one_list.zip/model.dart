// To parse this JSON data, do
//
//     final user = userFromJson(jsonString);

import 'dart:convert';

List<User> userFromJson(String str) =>
    List<User>.from(json.decode(str).map((x) => User.fromJson(x)));

String userToJson(List<User> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class User {
  User({
    this.success,
    this.clientInfos,
    this.projectInfos,
    this.ticketPriorityInfos,
    this.ticketTypeInfos,
    this.ticketModeInfos,
    this.ticketStatusInfos,
    this.ticketTitleInfos,
  });

  bool success;
  List<ClientInfo> clientInfos;
  List<ProjectInfo> projectInfos;
  List<TicketPriorityInfo> ticketPriorityInfos;
  List<TicketTypeInfo> ticketTypeInfos;
  List<TicketModeInfo> ticketModeInfos;
  List<TicketStatusInfo> ticketStatusInfos;
  List<TicketTitleInfo> ticketTitleInfos;

  factory User.fromJson(Map<String, dynamic> json) => User(
        success: json["success"],
        clientInfos: List<ClientInfo>.from(
            json["clientInfos"].map((x) => ClientInfo.fromJson(x))),
        projectInfos: List<ProjectInfo>.from(
            json["projectInfos"].map((x) => ProjectInfo.fromJson(x))),
        ticketPriorityInfos: List<TicketPriorityInfo>.from(
            json["ticketPriorityInfos"]
                .map((x) => TicketPriorityInfo.fromJson(x))),
        ticketTypeInfos: List<TicketTypeInfo>.from(
            json["ticketTypeInfos"].map((x) => TicketTypeInfo.fromJson(x))),
        ticketModeInfos: List<TicketModeInfo>.from(
            json["ticketModeInfos"].map((x) => TicketModeInfo.fromJson(x))),
        ticketStatusInfos: List<TicketStatusInfo>.from(
            json["ticketStatusInfos"].map((x) => TicketStatusInfo.fromJson(x))),
        ticketTitleInfos: List<TicketTitleInfo>.from(
            json["ticketTitleInfos"].map((x) => TicketTitleInfo.fromJson(x))),
      );

  Map<String, dynamic> toJson() => {
        "success": success,
        "clientInfos": List<dynamic>.from(clientInfos.map((x) => x.toJson())),
        "projectInfos": List<dynamic>.from(projectInfos.map((x) => x.toJson())),
        "ticketPriorityInfos":
            List<dynamic>.from(ticketPriorityInfos.map((x) => x.toJson())),
        "ticketTypeInfos":
            List<dynamic>.from(ticketTypeInfos.map((x) => x.toJson())),
        "ticketModeInfos":
            List<dynamic>.from(ticketModeInfos.map((x) => x.toJson())),
        "ticketStatusInfos":
            List<dynamic>.from(ticketStatusInfos.map((x) => x.toJson())),
        "ticketTitleInfos":
            List<dynamic>.from(ticketTitleInfos.map((x) => x.toJson())),
      };
}

class ClientInfo {
  ClientInfo({
    this.clientsId,
    this.clintName,
    this.cltSlogan,
    this.clintAbbr,
    this.adresInfo,
    this.webaddress,
    this.clintemail,
    this.cpasswords,
    this.telPhones,
    this.clintLogo,
    this.astatusFg,
    this.userdslNo,
    this.createdBy,
    this.createdAt,
    this.updatedBy,
    this.updatedAt,
    this.categoryid,
    this.mobPhones,
    this.cltDetail,
    this.companyId,
    this.cbranchId,
    this.cobunitId,
    this.ptgunitId,
    this.cemailGrp,
    this.recshowFg,
    this.bsnsdevFg,
    this.safsdevFg,
    this.supormxFg,
  });

  String clientsId;
  String clintName;
  dynamic cltSlogan;
  String clintAbbr;
  String adresInfo;
  String webaddress;
  String clintemail;
  dynamic cpasswords;
  dynamic telPhones;
  String clintLogo;
  String astatusFg;
  dynamic userdslNo;
  String createdBy;
  DateTime createdAt;
  dynamic updatedBy;
  dynamic updatedAt;
  String categoryid;
  String mobPhones;
  dynamic cltDetail;
  String companyId;
  String cbranchId;
  String cobunitId;
  String ptgunitId;
  dynamic cemailGrp;
  String recshowFg;
  String bsnsdevFg;
  String safsdevFg;
  String supormxFg;

  factory ClientInfo.fromJson(Map<String, dynamic> json) => ClientInfo(
        clientsId: json["CLIENTS_ID"],
        clintName: json["CLINT_NAME"],
        cltSlogan: json["CLT_SLOGAN"],
        clintAbbr: json["CLINT_ABBR"],
        adresInfo: json["ADRES_INFO"],
        webaddress: json["WEBADDRESS"],
        clintemail: json["CLINTEMAIL"],
        cpasswords: json["CPASSWORDS"],
        telPhones: json["TEL_PHONES"],
        clintLogo: json["CLINT_LOGO"],
        astatusFg: json["ASTATUS_FG"],
        userdslNo: json["USERDSL_NO"],
        createdBy: json["CREATED_BY"],
        createdAt: DateTime.parse(json["CREATED_AT"]),
        updatedBy: json["UPDATED_BY"],
        updatedAt: json["UPDATED_AT"],
        categoryid: json["CATEGORYID"],
        mobPhones: json["MOB_PHONES"],
        cltDetail: json["CLT_DETAIL"],
        companyId: json["COMPANY_ID"],
        cbranchId: json["CBRANCH_ID"],
        cobunitId: json["COBUNIT_ID"],
        ptgunitId: json["PTGUNIT_ID"],
        cemailGrp: json["CEMAIL_GRP"],
        recshowFg: json["RECSHOW_FG"],
        bsnsdevFg: json["BSNSDEV_FG"],
        safsdevFg: json["SAFSDEV_FG"],
        supormxFg: json["SUPORMX_FG"],
      );

  Map<String, dynamic> toJson() => {
        "CLIENTS_ID": clientsId,
        "CLINT_NAME": clintName,
        "CLT_SLOGAN": cltSlogan,
        "CLINT_ABBR": clintAbbr,
        "ADRES_INFO": adresInfo,
        "WEBADDRESS": webaddress,
        "CLINTEMAIL": clintemail,
        "CPASSWORDS": cpasswords,
        "TEL_PHONES": telPhones,
        "CLINT_LOGO": clintLogo,
        "ASTATUS_FG": astatusFg,
        "USERDSL_NO": userdslNo,
        "CREATED_BY": createdBy,
        "CREATED_AT": createdAt.toIso8601String(),
        "UPDATED_BY": updatedBy,
        "UPDATED_AT": updatedAt,
        "CATEGORYID": categoryid,
        "MOB_PHONES": mobPhones,
        "CLT_DETAIL": cltDetail,
        "COMPANY_ID": companyId,
        "CBRANCH_ID": cbranchId,
        "COBUNIT_ID": cobunitId,
        "PTGUNIT_ID": ptgunitId,
        "CEMAIL_GRP": cemailGrp,
        "RECSHOW_FG": recshowFg,
        "BSNSDEV_FG": bsnsdevFg,
        "SAFSDEV_FG": safsdevFg,
        "SUPORMX_FG": supormxFg,
      };
}

class ProjectInfo {
  ProjectInfo({
    this.projectId,
    this.projtName,
    this.projtDesc,
    this.clientsId,
    this.astatusFg,
    this.userdslNo,
    this.prStartat,
    this.prEndtoat,
    this.warntySat,
    this.warntyEat,
    this.supportrno,
    this.suportSat,
    this.suportEat,
    this.prCstatus,
    this.createdBy,
    this.createdAt,
    this.updatedBy,
    this.updatedAt,
    this.projtowner,
    this.scodeowner,
    this.refprojId,
    this.companyId,
    this.cbranchId,
    this.cobunitId,
    this.ptgunitId,
    this.pemailGrp,
    this.recshowFg,
    this.bsnsdevFg,
    this.safsdevFg,
    this.projtAbbr,
    this.productId,
    this.wkgpltpId,
  });

  String projectId;
  String projtName;
  dynamic projtDesc;
  String clientsId;
  String astatusFg;
  dynamic userdslNo;
  DateTime prStartat;
  dynamic prEndtoat;
  dynamic warntySat;
  dynamic warntyEat;
  dynamic supportrno;
  dynamic suportSat;
  dynamic suportEat;
  dynamic prCstatus;
  String createdBy;
  DateTime createdAt;
  dynamic updatedBy;
  dynamic updatedAt;
  String projtowner;
  String scodeowner;
  dynamic refprojId;
  String companyId;
  String cbranchId;
  String cobunitId;
  String ptgunitId;
  dynamic pemailGrp;
  String recshowFg;
  String bsnsdevFg;
  String safsdevFg;
  dynamic projtAbbr;
  dynamic productId;
  dynamic wkgpltpId;

  factory ProjectInfo.fromJson(Map<String, dynamic> json) => ProjectInfo(
        projectId: json["PROJECT_ID"],
        projtName: json["PROJT_NAME"],
        projtDesc: json["PROJT_DESC"],
        clientsId: json["CLIENTS_ID"],
        astatusFg: json["ASTATUS_FG"],
        userdslNo: json["USERDSL_NO"],
        prStartat: DateTime.parse(json["PR_STARTAT"]),
        prEndtoat: json["PR_ENDTOAT"],
        warntySat: json["WARNTY_SAT"],
        warntyEat: json["WARNTY_EAT"],
        supportrno: json["SUPPORTRNO"],
        suportSat: json["SUPORT_SAT"],
        suportEat: json["SUPORT_EAT"],
        prCstatus: json["PR_CSTATUS"],
        createdBy: json["CREATED_BY"],
        createdAt: DateTime.parse(json["CREATED_AT"]),
        updatedBy: json["UPDATED_BY"],
        updatedAt: json["UPDATED_AT"],
        projtowner: json["PROJTOWNER"],
        scodeowner: json["SCODEOWNER"],
        refprojId: json["REFPROJ_ID"],
        companyId: json["COMPANY_ID"],
        cbranchId: json["CBRANCH_ID"],
        cobunitId: json["COBUNIT_ID"],
        ptgunitId: json["PTGUNIT_ID"],
        pemailGrp: json["PEMAIL_GRP"],
        recshowFg: json["RECSHOW_FG"],
        bsnsdevFg: json["BSNSDEV_FG"],
        safsdevFg: json["SAFSDEV_FG"],
        projtAbbr: json["PROJT_ABBR"],
        productId: json["PRODUCT_ID"],
        wkgpltpId: json["WKGPLTP_ID"],
      );

  Map<String, dynamic> toJson() => {
        "PROJECT_ID": projectId,
        "PROJT_NAME": projtName,
        "PROJT_DESC": projtDesc,
        "CLIENTS_ID": clientsId,
        "ASTATUS_FG": astatusFg,
        "USERDSL_NO": userdslNo,
        "PR_STARTAT": prStartat.toIso8601String(),
        "PR_ENDTOAT": prEndtoat,
        "WARNTY_SAT": warntySat,
        "WARNTY_EAT": warntyEat,
        "SUPPORTRNO": supportrno,
        "SUPORT_SAT": suportSat,
        "SUPORT_EAT": suportEat,
        "PR_CSTATUS": prCstatus,
        "CREATED_BY": createdBy,
        "CREATED_AT": createdAt.toIso8601String(),
        "UPDATED_BY": updatedBy,
        "UPDATED_AT": updatedAt,
        "PROJTOWNER": projtowner,
        "SCODEOWNER": scodeowner,
        "REFPROJ_ID": refprojId,
        "COMPANY_ID": companyId,
        "CBRANCH_ID": cbranchId,
        "COBUNIT_ID": cobunitId,
        "PTGUNIT_ID": ptgunitId,
        "PEMAIL_GRP": pemailGrp,
        "RECSHOW_FG": recshowFg,
        "BSNSDEV_FG": bsnsdevFg,
        "SAFSDEV_FG": safsdevFg,
        "PROJT_ABBR": projtAbbr,
        "PRODUCT_ID": productId,
        "WKGPLTP_ID": wkgpltpId,
      };
}

class TicketModeInfo {
  TicketModeInfo({
    this.trModeId,
    this.tReqMode,
  });

  String trModeId;
  String tReqMode;

  factory TicketModeInfo.fromJson(Map<String, dynamic> json) => TicketModeInfo(
        trModeId: json["TR_MODE_ID"],
        tReqMode: json["T_REQ_MODE"],
      );

  Map<String, dynamic> toJson() => {
        "TR_MODE_ID": trModeId,
        "T_REQ_MODE": tReqMode,
      };
}

class TicketPriorityInfo {
  TicketPriorityInfo({
    this.tktPriId,
    this.tPriority,
  });

  String tktPriId;
  String tPriority;

  factory TicketPriorityInfo.fromJson(Map<String, dynamic> json) =>
      TicketPriorityInfo(
        tktPriId: json["TKT_PRI_ID"],
        tPriority: json["T_PRIORITY"],
      );

  Map<String, dynamic> toJson() => {
        "TKT_PRI_ID": tktPriId,
        "T_PRIORITY": tPriority,
      };
}

class TicketStatusInfo {
  TicketStatusInfo({
    this.tktstusId,
    this.tickstatus,
  });

  String tktstusId;
  String tickstatus;

  factory TicketStatusInfo.fromJson(Map<String, dynamic> json) =>
      TicketStatusInfo(
        tktstusId: json["TKTSTUS_ID"],
        tickstatus: json["TICKSTATUS"],
      );

  Map<String, dynamic> toJson() => {
        "TKTSTUS_ID": tktstusId,
        "TICKSTATUS": tickstatus,
      };
}

class TicketTitleInfo {
  TicketTitleInfo({
    this.cticketId,
    this.cstTitles,
    this.projectId,
  });

  String cticketId;
  String cstTitles;
  String projectId;

  factory TicketTitleInfo.fromJson(Map<String, dynamic> json) =>
      TicketTitleInfo(
        cticketId: json["CTICKET_ID"],
        cstTitles: json["CST_TITLES"],
        projectId: json["PROJECT_ID"],
      );

  Map<String, dynamic> toJson() => {
        "CTICKET_ID": cticketId,
        "CST_TITLES": cstTitles,
        "PROJECT_ID": projectId,
      };
}

class TicketTypeInfo {
  TicketTypeInfo({
    this.trTypeId,
    this.tReqType,
  });

  String trTypeId;
  String tReqType;

  factory TicketTypeInfo.fromJson(Map<String, dynamic> json) => TicketTypeInfo(
        trTypeId: json["TR_TYPE_ID"],
        tReqType: json["T_REQ_TYPE"],
      );

  Map<String, dynamic> toJson() => {
        "TR_TYPE_ID": trTypeId,
        "T_REQ_TYPE": tReqType,
      };
}
